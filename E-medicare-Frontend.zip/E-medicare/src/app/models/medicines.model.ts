export interface medicines{
    medicineId:number;
    medicineName:string;
    manufactureDate:string;
    type:string;
    price:number;
    description:string;
    expdate:string;
    status:string;
    seller:string;
    
}