import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationStatus } from '../models/authenticationstatus.model';
import { UserService } from '../services/user.service';
import { CartService } from '../services/cart.service';
import Swal from 'sweetalert2';
import { Registrationservice } from '../services/registration.service';
import { users } from '../models/users.model';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  authStatus: AuthenticationStatus | undefined;
  users: users | undefined;
  constructor(
    private registrationservice: Registrationservice,
    private userservice: UserService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {}
  onSubmit1(form: NgForm) {
    this.registrationservice
      .register(
        form.value.first_name,
        form.value.last_name,
        form.value.mobile_no,
        form.value.age,
        form.value.username,
        form.value.password,
        form.value.gender
      )
      .subscribe((reg) => {
        this.users = reg;
        Swal.fire('Registration Successfull !! Please Log-In To Proceed');
        this.router.navigate(['/user'], { relativeTo: this.route });
      });
  }
  onSubmit(form: NgForm) {
    console.log(form.value.username, form.value.password);

    this.userservice
      .authenticate(form.value.username, form.value.password)
      .subscribe((res) => {
        this.authStatus = res;
        if (this.authStatus.authenticated) {
          //alert("Successfully logged in!")
          Swal.fire('Log-In Suceessful !!');
          this.router.navigate(['/userpage'], { relativeTo: this.route });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Invalid Credentials - Try Again',
          });
          //alert("Invalid Credentials!")
          this.router.navigate(['/user'], { relativeTo: this.route });
          form.reset();
        }
      });
  }
}
